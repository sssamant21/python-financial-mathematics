"""Read explicit files and emit a validated summary."""
import argparse
import json
from pathlib import Path
from .core import analyze


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args(argv)
    result = analyze(args.input.read_bytes(), args.config.read_bytes())
    print(json.dumps(result, sort_keys=True, allow_nan=False))
    return 0
