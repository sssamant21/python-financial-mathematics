"""Public API for the educational inflow package."""
from .core import analyze

__all__ = ['analyze']
