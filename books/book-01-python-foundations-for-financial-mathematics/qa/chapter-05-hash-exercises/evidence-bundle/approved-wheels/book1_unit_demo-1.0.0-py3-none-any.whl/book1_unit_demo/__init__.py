
from decimal import Decimal


def checked_quantity(value: object) -> Decimal:
    if type(value) is not Decimal:
        raise TypeError("quantity must be an exact Decimal")
    if not value.is_finite() or value < 0:
        raise ValueError("quantity must be finite and nonnegative")
    return value
