
from book1_unit_demo import checked_quantity


def labeled_quantity(value: object) -> tuple[str, object]:
    return ("instrument_units", checked_quantity(value))
